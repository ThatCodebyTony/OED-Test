# Usage

## Developers

The [developer website](https://openenergydashboard.github.io/developer/) is available to learn about working with the OED project.

## Production/Sites

The [admin installation page](https://OpenEnergyDashboard.github.io/help/v0.7.0/adminInstallation.html) is available to learn about installing OED for a production environment (normal OED site). These are part of the overall admin help pages for OED.
