## Database Migration Scripts Usage

The scripts ``` dumpDatabase.sh ``` and ``` restoreDatabase.sh ``` are meant to be used to migrate OED's Postgres version from 10.13 to 15.1. See the admin help pages on migrations for usage.

If the scripts don't work, the design documents for database migration has manual steps to migrate the database.
