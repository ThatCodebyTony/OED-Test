/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

drop function IF EXISTS compressed_readings;
drop function IF EXISTS compressed_group_readings;
drop function IF EXISTS barchart_readings;
drop function IF EXISTS barchart_group_readings;
drop function IF EXISTS compressed_barchart_readings_2;
drop function IF EXISTS compressed_barchart_group_readings_2;
drop function IF EXISTS compare_readings;
drop function IF EXISTS group_compare_readings;
